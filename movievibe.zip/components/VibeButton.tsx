// This component is no longer needed - we use sliders instead of predefined vibe buttons
// Keeping file for now to avoid breaking imports, but it's deprecated